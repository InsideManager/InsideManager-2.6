<template>
  <div class="max-w-7xl mx-auto p-4 md:p-8 space-y-8">
    <div class="flex flex-col md:flex-row md:items-end justify-between gap-4">
      <header>
        <h1 class="text-3xl font-black text-gray-900 dark:text-white tracking-tighter">Reuniões</h1>
        <p class="text-gray-500 dark:text-gray-400">Gerencie e acompanhe os agendamentos</p>
      </header>
      <div class="flex flex-col md:flex-row gap-4 w-full md:w-auto">
        <!-- Filtro por Organização -->
        <div class="relative w-full md:w-64">
          <Building2 :size="16" class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <select 
            v-model="selectedOrgId"
            class="pl-9 pr-4 py-2 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl text-sm focus:ring-2 focus:ring-orange-500 outline-none transition-all w-full shadow-sm appearance-none"
          >
            <option value="all">Todas as Empresas</option>
            <option v-for="org in userOrgs" :key="org.id" :value="org.id">
              {{ org.name }}
            </option>
          </select>
        </div>

        <!-- Busca -->
        <div class="relative group w-full md:w-72">
          <Search :size="16" class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-orange-500 transition-colors" />
          <input 
            v-model="searchQuery" 
            type="text" 
            placeholder="Pesquisar reuniões..."
            class="pl-9 pr-4 py-2 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl text-sm focus:ring-2 focus:ring-orange-500 outline-none transition-all w-full shadow-sm"
          />
        </div>
      </div>
    </div>

    <div v-if="loading" class="p-8 text-center dark:text-gray-400">Carregando reuniões...</div>

    <div v-else class="space-y-12">
      <div v-if="generalError" class="mb-6">
        <ErrorDisplay :error="generalError" />
      </div>

      <!-- Seção: Minhas Reuniões -->
      <section>
        <div class="flex items-center gap-2 mb-6">
          <UserIcon :size="20" class="text-orange-500" />
          <h2 class="text-xl font-bold text-gray-900 dark:text-white">Minhas Reuniões</h2>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div v-if="myMeetings.length === 0" class="col-span-full">
            <Card class="p-8 text-center bg-gray-50/50 dark:bg-gray-900/50 border-dashed border-2 border-gray-200 dark:border-gray-800">
              <p class="text-gray-500 dark:text-gray-400">Você não possui reuniões marcadas com os filtros atuais.</p>
            </Card>
          </div>
          
          <Card 
            v-for="resv in myMeetings" 
            :key="resv.id"
            class="p-5 border-l-4 border-l-orange-600 shadow-lg hover:shadow-xl transition-shadow dark:bg-gray-900"
          >
            <MeetingCardContent :resv="resv" :is-owner="true" @delete="handleDeleteReservation" />
          </Card>
        </div>
      </section>

      <!-- Seção: Reuniões da Organização -->
      <section>
        <div class="flex items-center gap-2 mb-6">
          <Building2 :size="20" class="text-blue-500" />
          <h2 class="text-xl font-bold text-gray-900 dark:text-white">Reuniões da Organização</h2>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div v-if="orgMeetings.length === 0" class="col-span-full">
            <Card class="p-8 text-center bg-gray-50/50 dark:bg-gray-900/50 border-dashed border-2 border-gray-200 dark:border-gray-800">
              <p class="text-gray-500 dark:text-gray-400">Nenhuma outra reunião encontrada na organização.</p>
            </Card>
          </div>
          
          <Card 
            v-for="resv in orgMeetings" 
            :key="resv.id"
            class="p-5 border-l-4 border-l-blue-600 shadow-lg hover:shadow-xl transition-shadow dark:bg-gray-900 opacity-90"
          >
            <MeetingCardContent :resv="resv" :is-owner="false" @delete="handleDeleteReservation" />
          </Card>
        </div>
      </section>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed, onUnmounted, h } from 'vue';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  LayoutDashboard, 
  Trash2, 
  Search, 
  Building2, 
  User as UserIcon,
  MapPin
} from 'lucide-vue-next';
import { api } from '@/src/services/api';
import Button from './Button.vue';
import Card from './Card.vue';
import ErrorDisplay from './ErrorDisplay.vue';
import type { User, Reservation, Organization } from '@/src/types';

const props = defineProps<{
  user: User;
  onNavigate: (page: string) => void;
}>();

// Estado reativo
const reservations = ref<Reservation[]>([]);
const userOrgs = ref<Organization[]>([]);
const loading = ref(true);
const searchQuery = ref('');
const selectedOrgId = ref<string | number>('all');
const generalError = ref<string | null>(null);

// Componente interno para o conteúdo do card para evitar repetição
const MeetingCardContent = (props: { resv: Reservation, isOwner: boolean }, { emit }: any) => {
  return h('div', [
    h('div', { class: 'flex justify-between items-start mb-4' }, [
      h('div', [
        h('h4', { class: 'font-black text-lg text-gray-900 dark:text-white tracking-tight' }, props.resv.title || 'Reunião'),
        props.resv.organization_name ? h('span', { class: 'text-[10px] font-bold text-orange-600 uppercase tracking-widest' }, props.resv.organization_name) : null
      ]),
      props.isOwner ? h(Button, {
        variant: 'ghost',
        size: 'icon',
        onClick: () => emit('delete', props.resv.id),
        class: 'text-gray-400 hover:text-red-600'
      }, () => h(Trash2, { size: 20 })) : null
    ]),
    h('div', { class: 'space-y-3 text-sm text-gray-600 dark:text-gray-400' }, [
      h('div', { class: 'flex items-center gap-3 bg-gray-50 dark:bg-gray-800 p-2 rounded-lg' }, [
        h(LayoutDashboard, { size: 16, class: 'text-orange-500' }),
        h('span', { class: 'font-bold dark:text-white' }, props.resv.room_name || 'Sala não encontrada')
      ]),
      h('div', { class: 'flex items-center gap-3 px-1' }, [
        h(CalendarIcon, { size: 16, class: 'text-gray-400' }),
        h('span', safeFormat(props.resv.start_time, "dd 'de' MMMM"))
      ]),
      h('div', { class: 'flex items-center gap-3 px-1' }, [
        h(Clock, { size: 16, class: 'text-gray-400' }),
        h('span', { class: 'font-medium' }, `${safeFormat(props.resv.start_time, 'HH:mm')} às ${safeFormat(props.resv.end_time, 'HH:mm')}`)
      ]),
      !props.isOwner ? h('div', { class: 'flex items-center gap-3 px-1' }, [
        h(UserIcon, { size: 16, class: 'text-gray-400' }),
        h('span', `Agendado por: ${props.resv.user_name || 'Usuário'}`)
      ]) : null,
      props.resv.resources && props.resv.resources.length > 0 ? h('div', { class: 'pt-2 border-t border-gray-100 dark:border-gray-800' }, [
        h('p', { class: 'text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2' }, 'Recursos Reservados'),
        h('div', { class: 'flex flex-wrap gap-1.5' }, props.resv.resources.map(res => 
          h('span', { 
            key: res.id,
            class: 'px-2.5 py-1 bg-orange-50 dark:bg-orange-900/20 text-orange-700 dark:text-orange-300 rounded-md text-[10px] font-black uppercase tracking-wider border border-orange-100 dark:border-orange-800'
          }, res.name)
        ))
      ]) : null
    ])
  ]);
};

// Formatação segura de datas
const safeFormat = (dateStr: string, formatStr: string) => {
  try {
    if (!dateStr) return 'Data inválida';
    const date = parseISO(dateStr);
    if (isNaN(date.getTime())) return 'Data inválida';
    return format(date, formatStr, { locale: ptBR });
  } catch (e) {
    return 'Erro na data';
  }
};

// Filtro base comum
const filteredReservations = computed(() => {
  if (!Array.isArray(reservations.value)) return [];
  
  let filtered = reservations.value;

  // Filtro por Organização
  if (selectedOrgId.value !== 'all') {
    filtered = filtered.filter(r => Number(r.organization_id) === Number(selectedOrgId.value));
  }
  
  // Filtro por Busca
  if (searchQuery.value) {
    const q = searchQuery.value.toLowerCase();
    filtered = filtered.filter(r => {
      const title = (r.title || 'Reunião').toLowerCase();
      const room = (r.room_name || '').toLowerCase();
      const user = (r.user_name || '').toLowerCase();
      const org = (r.organization_name || '').toLowerCase();
      const dateStr = r.start_time ? safeFormat(r.start_time, 'dd/MM/yyyy').toLowerCase() : '';
      
      return title.includes(q) || room.includes(q) || user.includes(q) || org.includes(q) || dateStr.includes(q);
    });
  }
  
  return filtered;
});

// Minhas Reuniões
const myMeetings = computed(() => {
  return filteredReservations.value.filter(r => Number(r.user_id) === Number(props.user.id));
});

// Reuniões da Organização (outros usuários)
const orgMeetings = computed(() => {
  return filteredReservations.value.filter(r => Number(r.user_id) !== Number(props.user.id));
});

onMounted(() => {
  fetchData();
  window.addEventListener('app:data_change', handleDataChange);
});

onUnmounted(() => {
  window.removeEventListener('app:data_change', handleDataChange);
});

const handleDataChange = () => {
  fetchMeetings();
};

const fetchData = async () => {
  loading.value = true;
  await Promise.all([
    fetchMeetings(),
    fetchOrganizations()
  ]);
  loading.value = false;
};

const fetchMeetings = async () => {
  try {
    const resvData = await api.get('/reservations');
    reservations.value = resvData;
    generalError.value = null;
  } catch (err: any) {
    console.error('Erro ao buscar reuniões:', err);
    generalError.value = err.message || 'Erro ao carregar reuniões';
  }
};

const fetchOrganizations = async () => {
  try {
    const orgs = await api.get('/organizations/list');
    userOrgs.value = orgs;
  } catch (err) {
    console.error('Erro ao buscar organizações:', err);
  }
};

const handleDeleteReservation = async (id: number) => {
  if (!confirm('Deseja cancelar esta reunião?')) return;
  try {
    await api.delete(`/reservations/${id}`);
    fetchMeetings();
  } catch (err: any) {
    alert('Erro ao cancelar reunião: ' + err.message);
  }
};
</script>
